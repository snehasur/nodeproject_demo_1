<?php

/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */

?>

<footer class="pt-60 footer-bg-color">
    <div class="container">
        <div class="row footer-bottom-border">
            <div class="col-md-3">
                <div class="woncomp-footer-title pb-20">
                    <a href="#" class="woncomp-header-logo"><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/footerlogo.png" alt="Final-LOGO"></a>
                </div>
                <p class="">
                    Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ducimus quia magni praesentium
                    velit dolorum, eius porro! Quae iste natus animi provident cumque, repellat tempore quaerat id.

                </p>
            </div>
            <div class="col-md-2">
                <div class="woncomp-footer-title pb-20">
                    <h3 class="theme-white">Need Help?</h3>
                </div>
                <?php
                $primarymenu = array(
                    'theme_location'  => 'primary',
                    'menu'            => 'footer_need_help',
                    'container'       => '',
                    'container_class' => '',
                    'container_id'    => '',
                    'menu_class'      => '',
                    'menu_id'         => '',
                    'echo'            => true,
                    'fallback_cb'     => 'wp_page_menu',
                    'before'          => '',
                    'after'           => '',
                    'link_before'     => '',
                    'link_after'      => '',
                    'items_wrap'      => '<ul id="%1$s" class="%2$s woncomp-icon-list-item pb-15 letter-spaces">%3$s</ul>',
                    'add_li_class'    => 'woncomp-icon-list-item pb-1 semi-strong letter-space',
                    'add_a_class'     => 'woncomp-icon-list-text footer-color theme-white-hover',
                    //'depth'           => 0,
                    //'walker'          => ''
                );

                wp_nav_menu($primarymenu);
                ?>

            </div>
            <div class="col-md-2">
                <div class="woncomp-footer-title pb-20">
                    <h3 class="theme-white">The Company</h3>
                </div>
                <?php
                $primarymenu = array(
                    'theme_location'  => 'primary',
                    'menu'            => 'footer_the_company',
                    'container'       => '',
                    'container_class' => '',
                    'container_id'    => '',
                    'menu_class'      => '',
                    'menu_id'         => '',
                    'echo'            => true,
                    'fallback_cb'     => 'wp_page_menu',
                    'before'          => '',
                    'after'           => '',
                    'link_before'     => '',
                    'link_after'      => '',
                    'items_wrap'      => '<ul id="%1$s" class="%2$s woncomp-icon-list-item pb-15 letter-spaces">%3$s</ul>',
                    'add_li_class'    => 'woncomp-icon-list-item pb-1 semi-strong letter-space',
                    'add_a_class'     => 'woncomp-icon-list-text footer-color theme-white-hover',
                    //'depth'           => 0,
                    //'walker'          => ''
                );

                wp_nav_menu($primarymenu);
                ?>
            </div>
            <div class="col-md-2">
                <div class="woncomp-footer-title pb-20">
                    <h3 class="theme-white">Find Us On</h3>
                </div>
                <ul class="woncomp-icon-list-item pb-15 semi-strong letter-spaces">

                    <li class="woncomp-icon-list-item pb-1 semi-strong letter-space">
                        <a href="#"> <span class="woncomp-icon-list-text footer-color">Facebook</span> </a>
                    </li>
                    <li class="woncomp-icon-list-item pb-1 semi-strong letter-space">
                        <a href="#"> <span class="woncomp-icon-list-text footer-color">Twitter</span> </a>
                    </li>
                    <li class="woncomp-icon-list-item pb-1 semi-strong letter-space">
                        <a href="#"> <span class="woncomp-icon-list-text footer-color">Instagram</span> </a>
                    </li>
                    <li class="woncomp-icon-list-item pb-1 semi-strong letter-space">
                        <a href="#"> <span class="woncomp-icon-list-text footer-color">Youtube</span> </a>
                    </li>
                    <li class="woncomp-icon-list-item pb-1 semi-strong letter-space">
                        <a href="#"> <span class="woncomp-icon-list-text footer-color">Gucci Podcast</span> </a>
                    </li>
                    <li class="woncomp-icon-list-item pb-1 semi-strong letter-space">
                        <a href="#"> <span class="woncomp-icon-list-text footer-color">Pinterest</span> </a>
                    </li>
                    <li class="woncomp-icon-list-item pb-1 semi-strong letter-space">
                        <a href="#"> <span class="woncomp-icon-list-text footer-color">Snapchat</span> </a>
                    </li>
                </ul>
            </div>
            <div class="col-md-3">
                <div class="woncomp-footer-title pb-20">
                    <h3 class="theme-white">Contact Us</h3>
                </div>
                <div class="woncomp-text-editor woncomp-footer-text-editor woncomp-clearfix">
                    <p class="footer-color semi-strong pb-1 mb-0">Address:</p>
                    <p class="footer-color semi-strong">Room No 311, Dummy Address(Please Change It.),
                        Newtown, Kolkata, West Bengal – 700156</p>
                    <p class="footer-color">
                        <span>Phone: <a class="footer-color" href="tel:+919810412064">+91 98104
                                12064</a></span> <br>
                        <span style="opacity: 0;">Phone: </span><a class="footer-color" href="tel:+919883332510">+91
                            98833
                            32510</a><br>
                        <span style="opacity: 0;">Phone: </span><a class="footer-color" href="tel:+919830912985">+91
                            98309 12985</a>
                    </p>
                    <p class="footer-color">
                        <span>Email: <a class="footer-color text-bold" href="mailto:team@theadhopper.com">team@theadhopper.com</a></span> <br>

                    </p>
                </div>
            </div>
        </div>
        <div class="row py-3">
            <div class="col-md-8 col-sm-9 m-copyright_left">
                <div class="copyright ">
                    <p class="copyright theme-white m-0">
                        <span class=""> © </span>
                        <script>
                            document.write(new Date().getFullYear())
                        </script>

                        <span class="">The Ad Hopper. All Rights Reserved.</span>
                    </p>
                </div>
            </div>
            <div class="col-md-4 col-sm-3 m-copyright_right">
                <div class="socail-icons d-flex justify-content-end">
                    <h5 class="copyright-socail-text theme-white text-uppercase mx-2"> Follow Us At</h5>
                    <ul class="social-icon-box flex">
                        <li class="">
                            <span class="social-icon social-icon1 mx-1">
                                <a href="https://www.facebook.com/Woncomp-TechSolutions-103753605238718/?notif_id=1621405957222432&notif_t=page_fan&ref=notif" class="theme-bg-white"> <i class="fa fa-facebook theme-dark"></i> </a>
                            </span>
                        </li>
                        <li class="">
                            <span class="social-icon social-icon5 mx-1">
                                <a href="https://www.instagram.com/woncomptechsolutions/" class="theme-bg-white"> <i class="fa fa-instagram theme-dark"></i> </a>
                            </span>
                        </li>

                        <li class="">
                            <span class="social-icon social-icon2  mx-1">
                                <a href="https://twitter.com/WoncompTech" class="theme-bg-white"> <i class="fa fa-twitter theme-dark"></i> </a>
                            </span>
                        </li>


                        <li class="">
                            <span class="social-icon social-icon4 mx-1">
                                <a href="https://www.linkedin.com/company/woncomp-techsolutions" class="theme-bg-white"> <i class="fa fa-linkedin theme-dark"></i> </a>
                            </span>
                        </li>


                    </ul>

                </div>
            </div>

        </div>
    </div>
</footer>
<?php wp_footer(); ?>

</body>

</html>