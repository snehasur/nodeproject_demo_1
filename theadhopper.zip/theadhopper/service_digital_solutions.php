<?php
/* 
* Template Name: Product Jeweluxe 
*/
get_header();
?>


<!--#Banner-->
<section class="woncomp_banner woncomp_ds_banner common_banner_properties pos-relative theme-banner">
</section>

<!--Who Are We / About-->
<section class="woncomp-we-offer woncomp-service-bg-color py-60 pos-relative" id="services">
    <div class="container">
        <div class="woncomp_title pb-40">
            <h2 class="text-center text-uppercase theme-white title-border2">Digital Solutions</h2>
        </div>
        <div class="row">
            <div class="col-md-10 offset-md-1">
                <div class="woncomp-co-content text-center">
                    <p class="pb-2">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. In sit consectetur aut tempore?
                        Ducimus, ratione vel! Incidunt reiciendis nam, fuga doloremque et assumenda voluptates?
                        Quidem odit consequuntur velit. Nulla, animi.
                        Et quis excepturi molestiae ea deserunt numquam laudantium provident non praesentium,
                        aperiam aliquam assumenda minus earum ratione reiciendis voluptatibus iusto dolorum
                        necessitatibus! Soluta blanditiis ipsam voluptate, voluptas dolorem dignissimos similique.
                        Beatae, aperiam ipsum dolores dolore ab doloribus dolorem. Exercitationem maiores saepe aut
                        quos. Assumenda cum temporibus voluptatem adipisci optio aliquid quaerat tempora porro
                        pariatur eveniet! Aut ratione sed non eius.
                        Molestias suscipit sequi hic unde corrupti minima rem voluptatem? Harum, dignissimos velit
                        quos laborum labore aliquid nesciunt ipsam ad totam, veritatis natus mollitia. Nesciunt
                        adipisci quam quas delectus veniam recusandae.
                    </p>
                </div>
            </div>
        </div>

        <div class="row pt-3">
            <div class="col-md-10 offset-md-1">
                <div class="woncomp_second_title pb-40">
                    <h2 class="text-center text-uppercase theme-white">We Offer</h2>
                </div>
            </div>

            <div class="col-md-10 offset-md-1 mt-5">
                <div class="row dotted-border-bottom ">
                    <div class="col-md-3 dotted-border-right">
                        <div class="p-20 text-center">

                            <div class="services-icons pb-3"><i class="fa fa-puzzle-piece"></i></div>

                            <h3 class="our-service-title we-offer-title  theme-white  py-1"><a href="https://woncomp.in/web-development/" class="theme-white theme-color-hover text-uppercase">Market Expansion
                                    Strategies</a></h3>
                        </div>
                    </div>

                    <div class="col-md-3 dotted-border-right">
                        <div class="p-20  text-center">

                            <div class="services-icons pb-3"><i class="fa fa-video-camera"></i></div>

                            <h3 class="our-service-title we-offer-title theme-white  py-1"><a href="https://woncomp.in/web-development/" class="theme-white theme-color-hover text-uppercase">Trade Promotion And
                                    Merchandising</a></h3>
                        </div>
                    </div>

                    <div class="col-md-3 dotted-border-right">
                        <div class="p-20 text-center">

                            <div class="services-icons pb-3"><i class="fa fa-puzzle-piece"></i></div>

                            <h3 class="our-service-title we-offer-title  theme-white  py-1"><a href="https://woncomp.in/web-development/" class="theme-white theme-color-hover text-uppercase">Market Expansion
                                    Strategies</a></h3>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="p-20  text-center">

                            <div class="services-icons pb-3"><i class="fa fa-video-camera"></i></div>

                            <h3 class="our-service-title we-offer-title theme-white  py-1"><a href="https://woncomp.in/web-development/" class="theme-white theme-color-hover text-uppercase">Trade Promotion And
                                    Merchandising</a></h3>
                        </div>
                    </div>



                </div>

                <div class="row">
                    <div class="col-md-4 dotted-border-right">
                        <div class="p-20  text-center">

                            <div class="services-icons pb-3"><i class="fa fa-bar-chart"></i></div>

                            <h3 class="our-service-title we-offer-title theme-white  py-1"><a href="https://woncomp.in/web-development/" class="theme-white theme-color-hover text-uppercase">Competitive AnalysisAnd
                                    Insights</a></h3>
                        </div>
                    </div>
                    <div class="col-md-4 dotted-border-right">
                        <div class="p-20  text-center">

                            <div class="services-icons pb-3"><i class="fa fa-bar-chart"></i></div>

                            <h3 class="our-service-title we-offer-title theme-white  py-1"><a href="https://woncomp.in/web-development/" class="theme-white theme-color-hover text-uppercase">Competitive AnalysisAnd
                                    Insights</a></h3>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="p-20 text-center">

                            <div class="services-icons pb-3"><i class="fa fa-handshake-o"></i></div>

                            <h3 class="our-service-title we-offer-title theme-white  py-1"><a href="https://woncomp.in/web-development/" class="theme-white theme-color-hover text-uppercase">Strategic Partnerships And
                                    Collaborations</a></h3>
                        </div>
                    </div>
                </div>

            </div>




        </div>


    </div>
</section>


<!--Let's Discuss / Contact-->
<section class="woncomp-services woncomp-co-lets-discuss  py-60 pos-relative" id="lets-discuss">
    <div class="container">
        <div class="woncomp_title pb-40">
            <h4 class="text-center theme-dark montserrat-regular text-semi-bold lets-discuss-heading1 pb-1">Unlpck
                the digital realm's potential</h4>
            <h4 class="text-center theme-dark text-semi-bold lets-discuss-heading1">Connect us ato embark on a
                journey of tech-powered transformation!</h4>
        </div>
        <div class="row">
            <div class="col-md-10 offset-md-1">
                <div class="lets-content-wrapper">
                    <div class="left theme-bg-color p-5">
                        <h3 class="theme-white">Let us know how we can help you to boost up your business?</h3>
                    </div>
                    <div class="right">
                        <form action="#" class="">
                            <div class="row pb-3">
                                <div class="col">
                                    <input type="text" id="fullname" name="fullname" class="form-control lets-content-input" placeholder="Full Name" required>
                                </div>
                                <div class="col">
                                    <input type="text" name="company_name" class="form-control lets-content-input" placeholder="Company Name">
                                </div>
                            </div>

                            <div class="row pb-5">
                                <div class="col">
                                    <input type="text" name="email" class="form-control lets-content-input" placeholder="Email" required>
                                </div>
                                <div class="col">
                                    <input type="text" name="contact_no" class="form-control lets-content-input" placeholder="Contact Number" required>
                                </div>
                            </div>
                            <div class="row pb-2">
                                <div class="col">
                                    <h4 class="lets-content-exploring">What are you exploring about?</h4>
                                </div>
                            </div>

                            <div class="row pb-3">
                                <div class="col">
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="exploring" id="brand-management" value="brand_management" required>
                                        <label class="form-check-label lets-check-label" for="brand-management">Brand
                                            Management</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="exploring" id="digital-solution" value="digital_solution">
                                        <label class="form-check-label lets-check-label" for="digital-solution">Digital
                                            Solutions</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="exploring" id="commercial-outreach" value="commercial_outreach">
                                        <label class="form-check-label lets-check-label" for="commercial-outreach">Commercial
                                            Outreach</label>
                                    </div>
                                </div>
                            </div>

                            <div class="row pb-3">
                                <div class="col">
                                    <div class="mb-3">
                                        <label for="validationTextarea" class="form-label text-area-label">Message</label>
                                        <textarea class="form-control" id="message" placeholder="" required></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col">
                                    <div class="lets-btn-wrrapper float-right">
                                        <button class="lets_submit_btn woncomp-service-bg-color theme-white" type="submit">Submit</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>




<?php
get_footer();
?>