<?php
/*
 * Template Name: Who we are
 */
get_header();
?>

<!--#Banner-->
<section class="woncomp_banner woncomp_aout_banner common_banner_properties pos-relative theme-banner">
    <div class="curve_bottom"><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/shape-white.png" alt="" class="curve_bottom_img"></div>

</section>

<!--Who Are We / About-->
<section class="woncomp-about-us  py-60 pos-relative" id="lets-discuss">
    <div class="container">
        <div class="woncomp_title pb-40">
            <h2 class="text-center text-uppercase theme-dark semtext-semi-bold lets-discuss"><?php the_title(); ?></h2>
        </div>
        <div class="row">
            <div class="col-md-10 offset-md-1">
                <div class="woncomp-about-content text-center">
                    <?php the_content(); ?>

                </div>
            </div>
        </div>
    </div>
</section>

<?php
get_footer();
?>