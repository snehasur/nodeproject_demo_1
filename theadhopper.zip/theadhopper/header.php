<?php

/**
 * The header.
 *
 * This is the template that displays all of the <head> section and everything up until main.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */

global $post;
?>
<!doctype html>
<html <?php language_attributes(); ?> <?php twentytwentyone_the_html_classes(); ?>>

<head>
    <meta charset="<?php bloginfo('charset'); ?>" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
    <?php wp_body_open(); ?>
    <!--#Header-->

    <header class="woncomp-main-header w-100">

        <div class="header-nav w-100">
            <div class="container">
                <div class="d-flex align-items-center justify-content-between">
                    <a href="#" class="woncomp-header-logo"><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/logo.png" alt="Final-LOGO"></a>
                    <nav class="woncomp-nav">
                        <div class="hamburger">
                            <div class="hamburger-box">
                                <div class="hamburger-inner"></div>
                            </div>
                        </div>
                        <div class="woncomp-nav__sup woncomp-desktop-menu">
                            <?php
                            $primarymenu = array(
                                'theme_location'  => 'primary',
                                'menu'            => 'main_menu',
                                'container'       => '',
                                'container_class' => '',
                                'container_id'    => '',
                                'menu_class'      => '',
                                'menu_id'         => '',
                                'echo'            => true,
                                'fallback_cb'     => 'wp_page_menu',
                                'before'          => '',
                                'after'           => '',
                                'link_before'     => '',
                                'link_after'      => '',
                                'items_wrap'      => '<ul id="%1$s" class="%2$s woncomp-nav__sup__list">%3$s</ul>',
                                'add_li_class'    => '',
                                //'depth'           => 0,
                                //'walker'          => ''
                            );

                            wp_nav_menu($primarymenu);
                            ?>
                        </div>
                    </nav>
                    <div class="woncomp-header-right-btn">


                        <a href="#" class="header-btn-details header-btn-email"><i class="fa fa-envelope mr-1"></i>
                            team@theadhopper.com</a> |
                        <a href="#" class="header-btn-details header-btn-phone"><i class="fa fa-phone mr-1"></i>+91
                            98833
                            32510</a>

                    </div>
                </div>
            </div>
        </div>
        <div class="woncomp-nav__sup woncomp-mobile-menu">
            <?php
            $primarymenu = array(
                'theme_location'  => 'primary',
                'menu'            => 'header',
                'container'       => '',
                'container_class' => '',
                'container_id'    => '',
                'menu_class'      => '',
                'menu_id'         => '',
                'echo'            => true,
                'fallback_cb'     => 'wp_page_menu',
                'before'          => '',
                'after'           => '',
                'link_before'     => '',
                'link_after'      => '',
                'items_wrap'      => '<ul id="%1$s" class="%2$s woncomp-nav__sup__list">%3$s</ul>',
                'add_li_class'    => '',
                'depth'           => 0,
                'walker'          => ''
            );

            wp_nav_menu($primarymenu);
            ?>
        </div>
    </header>

    <!--#breadcrumb-->
    <?php //if (!is_front_page()) { 
    ?>
    <!-- <div class="woncomp-inner-banner w-100 d-flex align-items-center" style="background-image: url('<?php //echo get_stylesheet_directory_uri(); 
                                                                                                            ?>/assets/images/about/headingpic.jpg');">
            <div class="container">
                <div class="d-flex align-items-lg-center justify-content-lg-between">
                    <?php //woncomp_custom_breadcrumb(); 
                    ?>
                </div>


            </div>
        </div> -->
    <?php // } 
    ?>