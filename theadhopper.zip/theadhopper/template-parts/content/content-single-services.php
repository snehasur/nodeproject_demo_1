<?php

/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */

?>
<!--#Banner-->
<?php
$banner =  get_field('banner');
$post_id = $post->ID;

?>
<section class="woncomp_banner woncomp_co_banner common_banner_properties pos-relative theme-banner" style=" background: linear-gradient(0deg, rgba(0, 0, 0, 0.3), rgba(0, 0, 0, 0.3)), url('<?php echo $banner['banner_image']; ?>')">
	<div class="container">
		<div class="woncomp_title single-service-banner d-flex align-items-lg-center justify-content-lg-between">
			<h2 class="text-center text-uppercase theme-white title-border2"><?php the_title(); ?></h2>
		</div>
	</div>
	<div class="curve_bottom"><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/curved1.png" alt="" class="curve_bottom_img"></div>
</section>

<!--What We Offer-->
<section class="woncomp-we-offer woncomp-service-bg-color py-60 pos-relative" id="services">
	<div class="">
		<img src="http://localhost/theadhopper/wp-content/themes/theadhopper/assets/images/wave-right.png" alt="" class="wave-right-service service-wave-right">
	</div>
	<div class="">
		<img src="http://localhost/theadhopper/wp-content/themes/theadhopper/assets/images/wave-right.png" alt="" class="wave-left-service service-wave-left">
	</div>
	<div class="container">
		<div class="row">
			<div class="col-md-10 offset-md-1">
				<div class="woncomp-co-content text-center">

					<?php the_content(); ?>

				</div>
			</div>
		</div>

		<?php
		$weoffer =  get_field('we_offer');

		// echo '<pre>';
		// print_r($weoffer);
		// die();
		// echo 'Count = ' . count($weoffer);
		?>
		<div class="row pt-5">
			<div class="col-md-10 offset-md-1">
				<div class="woncomp_third_title pb-20">
					<h2 class="text-center text-uppercase theme-white">We Offer</h2>
				</div>
			</div>

			<div class="col-md-10 offset-md-1 mt-5">
				<?php
				// COMMERCIAL OUTREACH
				if ($post_id == 245) {
					for ($i = 1; $i <= count($weoffer); $i++) {
						$offer = 'offer_' . $i;
						$border_top = "dotted-border-top";

						if (!empty($weoffer[$offer]['title'])) {

							if ($i == 1 || $i == 3 || $i == 5 || $i == 7 || $i == 9 || $i == 11) {
								echo '<div class="row">';
							}
							if ($i != 1 || $i != 2) {
							}

							echo ($i % 2 != 0) ? '<div class="col-md-6 dotted-border-right ' . (($i != 1) ? $border_top : '') . '">' : '<div class="col-md-6 ' . (($i != 2) ? $border_top : '') . '">';

							echo '
								<div class="our-service-container com-service text-center">
									<div class="services-icons mb-3"><img src="' . $weoffer[$offer]['image'] . '" alt="" class=""></div>
									<h3 class="our-service-title we-offer-title  theme-white  py-1"><a href="#" class="theme-white theme-color-hover text-uppercase">' . $weoffer[$offer]['title'] . '</a></h3>
								</div>
							';
							echo '</div>';

							if ($i == 2 || $i == 4 || $i == 6 || $i == 8 || $i == 10 || $i == 12) {
								echo '</div>';
							}
						}
					}
				}
				?>


				<?php
				// DIGITAL SOLUTIONS
				if ($post_id == 247) {
					for ($i = 1; $i <= count($weoffer); $i++) {
						$offer = 'offer_' . $i;
						$border_top = "dotted-border-top";

						if (!empty($weoffer[$offer]['title'])) {

							if ($i == 1 || $i == 5 || $i == 9) {
								echo '<div class="row">';
							}

							echo ($i % 4 != 0) ? '
									<div class="we_offer_icons ' . (($i == 5 || $i == 6 || $i == 7) ? 'col-md-4' : 'col-md-3') . ' ' . (($i != 7) ? 'dotted-border-right ' : '') . ' ' . (($i != 1 && $i != 2 && $i != 3) ? $border_top : '') . ' ">' : '<div class="col-md-3 ' . (($i != 4) ? $border_top : '') . '"> ';

							echo '
								<div class="p-15 text-center">
									<div class="services-icons mb-3"><img src="' . $weoffer[$offer]['image'] . '" alt="" class=""></div>
									<h3 class="our-service-title we-offer-title  theme-white  py-1"><a href="#" class="theme-white theme-color-hover text-uppercase">' . $weoffer[$offer]['title'] . '</a></h3>
								</div>
							';
							echo '</div>';

							if ($i == 4 ||  $i == 8 || $i == 12) {
								echo '</div>';
							}
						}
					}
				}
				?>

				<?php
				// BRAND MANAGEMENT
				if ($post_id == 242) {
					for ($i = 1; $i <= count($weoffer); $i++) {
						$offer = 'offer_' . $i;
						$border_top = "dotted-border-top";
						$border_right = "dotted-border-right";

						if (!empty($weoffer[$offer]['title'])) {

							if ($i == 1 || $i == 4 || $i == 7 || $i == 11) {
								echo '<div class="row">';
							}
							if ($i != 1 || $i != 2) {
							}

							echo '<div class="col-md-4  
								' . (($i != 3 && $i != 6 && $i != 9 && $i != 12) ? $border_right  : '') . '
								' . (($i != 1 && $i != 2 && $i != 3) ? $border_top  : '') . '
								">';

							echo '
								<div class="our-service-container brand-service text-center">
									<div class="services-icons mb-3"><img src="' . $weoffer[$offer]['image'] . '" alt="" class=""></div>
									<h3 class="our-service-title we-offer-title theme-white py-1"><a href="#" class="theme-white theme-color-hover text-uppercase">' . $weoffer[$offer]['title'] . '</a></h3>
								</div>
							';
							echo '</div>';

							if ($i == 3 || $i == 6 || $i == 9 || $i == 12) {
								echo '</div>';
							}
						}
					}
				}
				?>


			</div>




		</div>


	</div>
</section>


<!--Let's Discuss / Contact-->
<section class="woncomp-services woncomp-co-lets-discuss  py-150_60 pos-relative" id="lets-discuss">
	<div class="curve_top"><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/curved5.png" alt="" class="curve_bottom_img"></div>

	<div class="container">
		<div class="woncomp_title pb-40">
			<h4 class="text-center theme-dark montserrat-regular text-semi-bold lets-discuss-heading1 pb-1">Open the
				door to endless
				possibilities</h4>
			<h4 class="text-center theme-dark text-semi-bold lets-discuss-heading1">Connect with us and unleash the
				power of strategic partnerships!</h4>
		</div>
		<div class="row">
			<div class="col-md-10 offset-md-1">
				<div class="lets-content-wrapper">
					<div class="left theme-bg-color p-5">
						<h3 class="theme-white">Let us know how we can help you to boost up your business?</h3>
					</div>
					<div class="right">
						<form action="#" class="">
							<div class="row pb-3">
								<div class="col">
									<input type="text" id="fullname" name="fullname" class="form-control lets-content-input" placeholder="Full Name" required>
								</div>
								<div class="col">
									<input type="text" name="company_name" class="form-control lets-content-input" placeholder="Company Name">
								</div>
							</div>

							<div class="row pb-5">
								<div class="col">
									<input type="text" name="email" class="form-control lets-content-input" placeholder="Email" required>
								</div>
								<div class="col">
									<input type="text" name="contact_no" class="form-control lets-content-input" placeholder="Contact Number" required>
								</div>
							</div>
							<div class="row pb-2">
								<div class="col">
									<h4 class="lets-content-exploring">What are you exploring about?</h4>
								</div>
							</div>

							<div class="row pb-3">
								<div class="col">
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="exploring" id="brand-management" value="brand_management" required>
										<label class="form-check-label lets-check-label" for="brand-management">Brand
											Management</label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="exploring" id="digital-solution" value="digital_solution">
										<label class="form-check-label lets-check-label" for="digital-solution">Digital
											Solutions</label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="exploring" id="commercial-outreach" value="commercial_outreach">
										<label class="form-check-label lets-check-label" for="commercial-outreach">Commercial
											Outreach</label>
									</div>
								</div>
							</div>

							<div class="row pb-3">
								<div class="col">
									<div class="mb-3">
										<label for="validationTextarea" class="form-label text-area-label">Message</label>
										<textarea class="form-control" id="message" placeholder="" required></textarea>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col">
									<div class="lets-btn-wrrapper float-right">
										<button class="lets_submit_btn woncomp-service-bg-color theme-white" type="submit">Submit</button>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>