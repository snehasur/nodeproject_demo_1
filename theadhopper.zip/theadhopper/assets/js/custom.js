"use strict";

/*==================
    Menu
===================*/
jQuery(function (jQuery) {
    jQuery('.hamburger-box').on('click', function () {
        jQuery(this).parent().toggleClass('is-active');
        jQuery('.woncomp-nav__sup.woncomp-mobile-menu').slideToggle();
        //jQuery('.woncomp-nav__sup').toggleClass('is-active');
    });
    jQuery('.woncomp-nav__sup ul > li > ul').parent().prepend('<i class="arw-nav fa fa-caret-down"></i>');

    function subMenu() {
        jQuery(this).parent('li').find('> ul').stop(true, true).slideToggle();
        jQuery(this).parents('li').siblings().find('ul').stop(true, true).slideUp();
        jQuery(this).toggleClass('actv');
        jQuery(this).parent().siblings().find('.arw-nav').removeClass('actv');
    }
    jQuery('.woncomp-nav__sup ul > li > .arw-nav').on('click', subMenu);

});

/*==================
   Banner
===================*/
jQuery('.woncomp-banner-slider').owlCarousel({
    loop: true,
    margin: 30,
    autoHeight: true,
    nav: true,
    navText: ['<span aria-label="Previous">‹</span>', '<span aria-label="Next">›</span>'],
    dots: true,
    autoplay: true,

    slideSpeed: 2000,
    paginationSpeed: 400,
    // margin: 25,
    responsiveClass: true,
    responsive: {
        0: {
            items: 1,
            nav: false
        },
        600: {
            items: 1,
            nav: false
        },
        1000: {
            items: 1,
            nav: true,
        }
    }
});

/*==================
   INDUSTRIES
===================*/
jQuery('.woncomp-industries-slider').owlCarousel({
    loop: true,
    // autoHeight: true,
    nav: false,
    navText: ['<span aria-label="Previous">‹</span>', '<span aria-label="Next">›</span>'],
    dots: true,
    // autoplay: true,
    slideSpeed: 2000,
    paginationSpeed: 400,
    // margin: 25,
    responsiveClass: true,
    responsive: {
        0: {
            items: 2,
            nav: false
        },
        600: {
            items: 3,
            nav: false
        },
        1000: {
            items: 4,
            nav: true,
        }
    }
});


/*==================
    Our Partner
===================*/
jQuery('.woncomp-upper-slider').owlCarousel({
    loop: true,
    autoHeight: true,
    nav: true,
    dots: false,
    // autoplay: true,
    slideSpeed: 2000,
    paginationSpeed: 400,
    margin: 25,
    responsiveClass: true,
    responsive: {
        0: {
            items: 1,
            nav: false
        },
        600: {
            items: 2,
            nav: false
        },
        1000: {
            items: 3,
            nav: true,
        }
    }
});

// jQuery('.woncomp-inner-slider').slick({
//     slidesToShow: 4,
//     slidesToScroll: 1,
//     autoplay: true,
//     autoplaySpeed: 2000,
//     infinite: true
// });


/*==================
    Menu
===================*/

(function (jQuery) {
    jQuery(function () {
        jQuery('nav ul li a:not(:only-child)').click(function (e) {
            jQuery(this).siblings('.nav-dropdown').toggle();
            jQuery('.dropdown').not(jQuery(this).siblings()).hide();
            e.stopPropagation();
        });
        jQuery('html').click(function () {
            jQuery('.nav-dropdown').hide();
        });
        jQuery('#nav-toggle').click(function () {
            jQuery('nav ul').slideToggle();
        });
        jQuery('#nav-toggle').on('click', function () {
            this.classList.toggle('active');
        });
    });
})(jQuery);



/*==================
    Menu
===================*/
jQuery(function () {
    let txt = jQuery(".woncomp-auto-text").text();
    // alert("text=" + txt)
    jQuery(".woncomp-auto-text").typed({
        strings: [txt, "About The AdHopper Innovative Ideas"],
        // Optionally use an HTML element to grab strings from (must wrap each string in a <p>)
        stringsElement: null,
        // typing speed
        typeSpeed: 30,
        // time before typing starts
        startDelay: 500,
        // backspacing speed
        backSpeed: 20,
        // time before backspacing
        backDelay: 500,
        // loop
        loop: true,
        // false = infinite
        loopCount: 5,
        // show cursor
        showCursor: false,
        // character for cursor
        cursorChar: "|",
        // attribute to type (null == text)
        attr: null,
        // either html or text
        contentType: 'html',
        // call when done callback function
        callback: function () { },
        // starting callback function before each string
        preStringTyped: function () { },
        //callback for every typed string
        onStringTyped: function () { },
        // callback for reset
        resetCallback: function () { }
    });
});


/* -------------------
    Smooth scrolling to anchor
    ---------------------*/
jQuery(jQuery => {
    // The speed of the scroll in milliseconds
    const speed = 1000;

    jQuery('a[href*="#"]')
        .filter((i, a) => a.getAttribute('href').startsWith('#') || a.href.startsWith(`jQuery{location.href}#`))
        .unbind('click.smoothScroll')
        .bind('click.smoothScroll', event => {
            const targetId = event.currentTarget.getAttribute('href').split('#')[1];
            const targetElement = document.getElementById(targetId);

            if (targetElement) {
                event.preventDefault();
                jQuery('html, body').animate({ scrollTop: jQuery(targetElement).offset().top }, speed);
            }
        });
});



var groups = {};
jQuery('.galleryItem').each(function () {
    var id = parseInt(jQuery(this).attr('data-group'), 10);

    if (!groups[id]) {
        groups[id] = [];
    }

    groups[id].push(this);
});


jQuery.each(groups, function () {

    jQuery(this).magnificPopup({
        type: 'image',
        closeOnContentClick: true,
        closeBtnInside: false,
        removalDelay: 300,
        mainClass: 'mfp-fade',
        gallery: { enabled: true },
        zoom: {
            enabled: true,
            duration: 300,
            easing: 'ease-in-out',
            opener: function (openerElement) {
                return openerElement.is('img') ? openerElement : openerElement.find('img');
            }
        }
    })

});