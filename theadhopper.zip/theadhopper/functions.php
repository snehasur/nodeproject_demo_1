<?php
add_action('wp_enqueue_scripts', 'woncomp_custom_scripts');
function woncomp_custom_scripts()
{
	// Note, the is_IE global variable is defined by WordPress and is used
	// to detect if the current browser is internet explorer.

	wp_enqueue_style('bootstrap_style', get_stylesheet_directory_uri() . '/assets/css/bootstrap.min.css', array(), wp_get_theme()->get('Version'));
	wp_enqueue_style('font_awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css', array(), wp_get_theme()->get('Version'));
	wp_enqueue_style('owl_default', get_stylesheet_directory_uri() . '/assets/css/owl.theme.default.min.css', array(), wp_get_theme()->get('Version'));
	wp_enqueue_style('owl', get_stylesheet_directory_uri() . '/assets/css/owl.carousel.min.css', array(), wp_get_theme()->get('Version'));
	wp_enqueue_style('slick_theme', 'https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick-theme.css', array(), wp_get_theme()->get('Version'));
	wp_enqueue_style('slick', 'https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css', array(), wp_get_theme()->get('Version'));
	wp_enqueue_style('magnific_css', get_stylesheet_directory_uri() . '/assets/css/magnific-popup.css', array(), wp_get_theme()->get('Version'));
	wp_enqueue_style('custom_style', get_stylesheet_directory_uri() . '/assets/css/custom.css', array(), wp_get_theme()->get('Version'));
	wp_enqueue_style('responsive', get_stylesheet_directory_uri() . '/assets/css/responsive.css', array(), wp_get_theme()->get('Version'));


	// Embeds script.
	wp_enqueue_script('jQuery', get_stylesheet_directory_uri() . '/assets/js/jquery.min.js', array(), '',  true);
	wp_enqueue_script('proper', get_stylesheet_directory_uri() . '/assets/js/popper.min.js', array(), '', true);
	wp_enqueue_script('bootstrap', get_stylesheet_directory_uri() . '/assets/js/bootstrap.min.js', array(), '', true);
	wp_enqueue_script('owl_js', get_stylesheet_directory_uri() . '/assets/js/owl.carousel.min.js', array(), '', true);
	wp_enqueue_script('typed', get_stylesheet_directory_uri() . '/assets/js/typed.min.js', array(), '', true);
	wp_enqueue_script('slick_js', get_stylesheet_directory_uri() . '/assets/js/slick.min.js', array(), '', true);
	wp_enqueue_script('slick_js', get_stylesheet_directory_uri() . '/assets/js/slick.min.js', array(), '', true);
	wp_enqueue_script('magnific_js', get_stylesheet_directory_uri() . '/assets/js/magnific-popup.min.js', array(), '', true);
	wp_enqueue_script('custom_js', get_stylesheet_directory_uri() . '/assets/js/custom.js', array(), '', true);
}

function woncomp_parent_css_dequeue_styles()
{

	// dequeue the Twenty Twenty-One parent style
	wp_dequeue_style('twenty-twenty-one-style');
	wp_dequeue_script('twenty-twenty-one-style');
}
add_action('wp_enqueue_scripts', 'woncomp_parent_css_dequeue_styles', 11);





/*=======================
	Custom Breadcrumb
=======================*/


function woncomp_custom_breadcrumb()
{
	echo '<ul id="breadcrumbs">';
	echo '<li><a href="' . home_url() . '" rel="nofollow">Home</a></li>';
	if (is_category() || is_single()) {
		//echo "&nbsp;&nbsp;&#187;&nbsp;&nbsp;";
		echo '<li>';
		the_category(' ');
		echo '</li>';
		if (is_single()) {
			//echo " &nbsp;&nbsp;&#187;&nbsp;&nbsp; ";
			echo '<li> <h1>';
			the_title();
			echo '</li> </h1>';
		}
	} elseif (is_page()) {
		// echo " &nbsp;&nbsp;&#187;&nbsp;&nbsp;";
		echo '<li> <h1>';
		echo the_title();
		echo '</li> </h1>';
	} elseif (is_search()) {
		//echo "&nbsp;&nbsp;&#187;&nbsp;&nbsp;Search Results for... ";
		echo '<li> "<em>';
		echo the_search_query();
		echo '</em>" </li>';
	}
	echo '</ul>';
}



/*================
	Custom Post(Services)
================*/


function custom_post_services()
{

	$args = array(
		'labels'        => array(
			'name'               => _x('Services', 'services'),
			'singular_name'      => _x('Service', 'services'),
			'add_new'            => _x('Add New', 'services'),
			'add_new_item'       => __('Add New services'),
			'edit_item'          => __('Edit services'),
			'new_item'           => __('New services'),
			'all_items'          => __('All services'),
			'view_item'          => __('View services'),
			'search_items'       => __('Search services'),
			'not_found'          => __('No services found'),
			'not_found_in_trash' => __('No services found in the Trash'),
			'parent_item_colon'  => '',
			'menu_name'          => 'Services'

		),
		'description'   => 'services',
		'public'        => true,
		'show_ui'        => true,
		'capability_type'  => 'post',
		'menu_position' => 5,
		'menu_icon'		   => 'dashicons-businessman',
		'supports'      => array('title', 'thumbnail', 'editor', 'page-attributes', 'excerpt'),
		'taxonomies'    => array('category', 'post_tag'),
		'has_archive'   => true,
		'rewrite'		  => true,
	);

	register_post_type('service', $args);
}
add_action('init', 'custom_post_services');



/*================
	Custom Post(Products)
================*/


function custom_post_products()
{

	$args = array(
		'labels'        => array(
			'name'               => _x('Products', 'products'),
			'singular_name'      => _x('Product', 'products'),
			'add_new'            => _x('Add New', 'products'),
			'add_new_item'       => __('Add New products'),
			'edit_item'          => __('Edit products'),
			'new_item'           => __('New products'),
			'all_items'          => __('All products'),
			'view_item'          => __('View products'),
			'search_items'       => __('Search products'),
			'not_found'          => __('No products found'),
			'not_found_in_trash' => __('No products found in the Trash'),
			'parent_item_colon'  => '',
			'menu_name'          => 'Products'

		),
		'description'   => 'products',
		'public'        => true,
		'show_ui'        => true,
		'capability_type'  => 'post',
		'menu_position' => 5,
		'menu_icon'		   => 'dashicons-admin-site',
		'supports'      => array('title', 'thumbnail', 'editor', 'page-attributes', 'excerpt'),
		'taxonomies'    => array('category', 'post_tag'),
		'has_archive'   => true,
		'rewrite'		  => array('slug' => 'products'),
	);

	register_post_type('product', $args);
}
add_action('init', 'custom_post_products');









/*==============================
	Custom Post(Industries)
===============================*/


function custom_post_industries()
{

	$args = array(
		'labels'        => array(
			'name'               => _x('Industries', 'industries'),
			'singular_name'      => _x('Industry', 'industries'),
			'add_new'            => _x('Add New', 'industries'),
			'add_new_item'       => __('Add New industries'),
			'edit_item'          => __('Edit industries'),
			'new_item'           => __('New industries'),
			'all_items'          => __('All industries'),
			'view_item'          => __('View industries'),
			'search_items'       => __('Search industries'),
			'not_found'          => __('No industries found'),
			'not_found_in_trash' => __('No industries found in the Trash'),
			'parent_item_colon'  => '',
			'menu_name'          => 'Industries'

		),
		'description'   => 'industries',
		'public'        => true,
		'show_ui'        => true,
		'capability_type'  => 'post',
		'menu_position' => 5,
		'menu_icon'		   => 'dashicons-admin-site',
		'supports'      => array('title', 'thumbnail', 'editor', 'page-attributes', 'excerpt'),
		'taxonomies'    => array('category', 'post_tag'),
		'has_archive'   => true,
		'rewrite'		  => array('slug' => 'industries'),
	);

	register_post_type('industries', $args);
}
add_action('init', 'custom_post_industries');




/*=================
	Add li Class
==================*/
function woncomp_add_additional_class_on_li($classes, $item, $args)
{
	if (isset($args->add_li_class)) {
		$classes[] = $args->add_li_class;
	}
	return $classes;
}
add_filter('nav_menu_css_class', 'woncomp_add_additional_class_on_li', 1, 3);


/*================================
	Add li Anchor Tag Class
================================*/

function woncomp_add_additional_class_on_a($classes, $item, $args)
{
	if (isset($args->add_a_class)) {
		$classes['class'] = $args->add_a_class;
	}
	return $classes;
}

add_filter('nav_menu_link_attributes', 'woncomp_add_additional_class_on_a', 1, 3);

/*==============
	Footer Widget
===============*/

register_sidebar(array(
	'name' => __('Footer', 'rmccollin'),
	'id' => 'custom-footer',
	'description' => __('This is a custom footer.', 'woncomp'),
	'before_widget' => '<div id="%1$s" class="widget-container %2$s">',
	'after_widget' => '</div>',
	'before_title' => '<h3 class="widget-title">',
	'after_title' => '</h3>',
));
