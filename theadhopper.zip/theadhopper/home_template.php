<?php
/* Template Name: Homepage */
get_header();
?>


<!--#Banner-->
<?php
$home_banner = get_field('home_banner');
// echo '<pre>';

// print_r($home_banner);
// die();


?>
<section class="woncomp_banner woncomp_banner_curved pos-relative theme-banner">
    <?php if (!empty($home_banner)) { ?>

        <div class="owl-carousel owl-theme  woncomp-banner-slider" id="woncomp-banner">
            <?php
            for ($i = 1; $i <= count($home_banner); $i++) {
                $banner_count = 'banner_image_' . $i;
                $banner_image = $home_banner[$banner_count]['image'];
            ?>
                <div class="item">
                    <div class="our-banner-container">
                        <img src="<?php echo $banner_image;  ?>" alt="<?php echo $banner_count;  ?>" />
                    </div>
                </div>
            <?php
            }
            ?>
        </div>
    <?php } else {
        echo '<p>' .  _e('Please add at least one image for banner.') . '</p>';;
    ?>

    <?php } ?>
    <div class="curve_bottom"><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/curved1.png" alt="" class="curve_bottom_img"></div>
</section>

<!--Our Expertise / Services-->
<section class="woncomp-services our-expertise-curve woncomp-service-bg-color py-60 pos-relative" id="services">
    <div class="our-expertise-curve-wrapper">
        <div class="container">
            <div class="woncomp_title pb-40">
                <h2 class="text-center text-uppercase theme-white semtext-semi-bold">OUR EXPERTISE</h2>
            </div>
            <div class="owl-carousel owl-carousel-expertise owl-theme woncomp-upper-slider" id="woncomp-service">
                <?php
                // the query
                $i = 1;
                $wpb_all_query = new WP_Query(array('post_type' => 'services', 'post_status' => 'publish', 'order' => 'asc')); ?>
                <?php if ($wpb_all_query->have_posts()) : ?>
                    <?php while ($wpb_all_query->have_posts()) : $wpb_all_query->the_post(); ?>

                        <div class="item">

                            <div class="our-service-container our-expertise text-center px-50">

                                <div class="services-icons p-30"><?php the_post_thumbnail() ?></div>

                                <h3 class="our-service-title py-10"><a href="<?php the_permalink(); ?>" class="theme-color-hover theme-white text-uppercase"><?php the_title(); ?></a></h3>
                                <div class="excerpt_wrapper">
                                    <?php the_excerpt(); ?>
                                </div>

                                <a href="<?php the_permalink() ?>" class="know-more-btn">
                                    <div class="custom-btn text-uppercase text-center theme-white m-auto">
                                        Know More
                                    </div>
                                </a>

                            </div>

                        </div>

                    <?php $i++;
                    endwhile; ?>
                    <?php wp_reset_postdata(); ?>

                <?php else : ?>
                    <p><?php _e('Sorry, no posts matched your criteria.'); ?></p>
                <?php endif; ?>



            </div>
        </div>
    </div>

</section>

<!--Industries-->
<section class="woncomp-industries woncomp-industries-bg-color py-150 pos-relative" id="industries" style="background-color: black;">
    <div class="curve_top"><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/curved2.png" alt="" class="curve_bottom_img"></div>
    <div class="container">
        <div class="woncomp_title pb-40">
            <h2 class="text-center text-uppercase theme-white semtext-semi-bold">Industries</h2>
        </div>
    </div>
    <div class="owl-carousel owl-theme  woncomp-industries-slider" id="woncomp-industries-slider">
        <?php
        // the query
        $wpb_all_query = new WP_Query(array('post_type' => 'industries', 'post_status' => 'publish', 'order' => 'asc')); ?>
        <?php if ($wpb_all_query->have_posts()) : ?>
            <?php while ($wpb_all_query->have_posts()) : $wpb_all_query->the_post(); ?>
                <div class="item">
                    <div class="industries-container pos-relative">
                        <?php the_post_thumbnail() ?>

                        <!-- <div class="industries-silder-content pos-absolute button-1">
                            <h3 class="theme-dark montserrat-regular text-center"><?php the_title(); ?></h3>
                        </div> -->
                        <div class="industries-silder-content pos-absolute button-1"><a class="click-btn btn-style507" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></div>
                    </div>
                </div>

            <?php endwhile; ?>
            <?php wp_reset_postdata(); ?>

        <?php else : ?>
            <p><?php _e('Sorry, no posts matched your criteria.'); ?></p>
        <?php endif; ?>

    </div>

    <div class="curve_bottom"><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/curved3.png" alt="" class="curve_bottom_img"></div>

</section>


<!--Who Are We / About-->

<?php
$who_we_are = get_field('who_we_are');
// echo '<pre>';
// print_r($who_we_are);


$wwr_image = $who_we_are['image'];
$wwr_heading = $who_we_are['heading'];
$wwr_title = $who_we_are['title'];
$wwr_para = $who_we_are['content'];
$wwr_btn_text = $who_we_are['button_text'];
$wwr_btn_link = $who_we_are['button_link'];

?>
<section class="woncomp-services woncomp-service-bg-color py-60 pos-relative" id="services">
    <div class="">
        <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/wave-right.png" alt="" class="wave-right home-wave-right">
    </div>
    <div class="container">
        <div class="woncomp_title pb-40">
            <h2 class="text-center text-uppercase theme-white semtext-semi-bold"><?php echo $wwr_heading; ?></h2>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="img-wrapper text-center">
                    <img src="<?php echo $wwr_image ?>" alt="" class="who_we_are_img">
                </div>
            </div>
            <div class="col-md-6">
                <div class="who_we_are_content_wrapper">
                    <h3 class="who-we-are-title theme-white woncomp-auto-text"><?php echo $wwr_title; ?></h3>
                    <?php echo $wwr_para ?>
                    <a href="<?php echo $wwr_btn_link ?>" class="know-more-btn">
                        <div class="custom-btn text-uppercase text-center theme-white">
                            <?php echo $wwr_btn_text ?>
                        </div>
                    </a>
                </div>
            </div>


        </div>
    </div>
</section>


<!--Let's Discuss / Contact-->
<section class="woncomp-services woncomp-lets-discuss  py-150 pos-relative" id="lets-discuss">
    <div class="curve_top"><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/curved5.png" alt="" class="curve_bottom_img"></div>

    <div class="">
        <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/wave-left-green.png" alt="" class="wave-left home-wave-left">
    </div>
    <div class="container">
        <div class="woncomp_title pb-40">
            <h2 class="text-center text-uppercase theme-dark semtext-semi-bold lets-discuss">Let's Discuss More</h2>
        </div>
        <div class="row">
            <div class="col-md-10 offset-md-1">
                <div class="lets-content-wrapper">
                    <div class="left theme-bg-color p-5">
                        <h3 class="theme-white">Let us know how we can help you to boost up your business?</h3>
                    </div>
                    <div class="right">
                        <form action="#" class="">
                            <div class="row pb-3">
                                <div class="col">
                                    <input type="text" id="fullname" name="fullname" class="form-control lets-content-input" placeholder="Full Name" required>
                                </div>
                                <div class="col">
                                    <input type="text" name="company_name" class="form-control lets-content-input" placeholder="Company Name">
                                </div>
                            </div>

                            <div class="row pb-5">
                                <div class="col">
                                    <input type="text" name="email" class="form-control lets-content-input" placeholder="Email" required>
                                </div>
                                <div class="col">
                                    <input type="text" name="contact_no" class="form-control lets-content-input" placeholder="Contact Number" required>
                                </div>
                            </div>
                            <div class="row pb-2">
                                <div class="col">
                                    <h4 class="lets-content-exploring">What are you exploring about?</h4>
                                </div>
                            </div>

                            <div class="row pb-3">
                                <div class="col">
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="exploring" id="brand-management" value="brand_management" required>
                                        <label class="form-check-label lets-check-label" for="brand-management">Brand
                                            Management</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="exploring" id="digital-solution" value="digital_solution">
                                        <label class="form-check-label lets-check-label" for="digital-solution">Digital
                                            Solutions</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="exploring" id="commercial-outreach" value="commercial_outreach">
                                        <label class="form-check-label lets-check-label" for="commercial-outreach">Commercial
                                            Outreach</label>
                                    </div>
                                </div>
                            </div>

                            <div class="row pb-3">
                                <div class="col">
                                    <div class="mb-3">
                                        <label for="validationTextarea" class="form-label text-area-label">Message</label>
                                        <textarea class="form-control" id="message" placeholder="" required></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col">
                                    <div class="lets-btn-wrrapper float-right">
                                        <button class="lets_submit_btn woncomp-service-bg-color theme-white" type="submit">Submit</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php
get_footer();
?>